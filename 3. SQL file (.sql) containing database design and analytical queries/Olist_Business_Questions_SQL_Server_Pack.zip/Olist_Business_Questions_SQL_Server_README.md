# Olist Business Questions — SQL Server

## What this file does
The SQL file contains analytical queries for the Olist end-to-end project after tables have been imported. It follows the Final Project requirements by using joins, aggregations, CTEs, subqueries (LEFT JOIN anti-join checks) and window functions (LAG, ROW_NUMBER, RANK, running totals).

## Before running
- The script targets Microsoft SQL Server and starts with `USE [OlistDB]`.
- It assumes these `dbo` names, consistent with prior SQL Server errors in the project: `customers`, `orders`, `order_items`, `order_payments`, `order_reviews`, `products`, `sellers`, `category_translation`, `geolocation`.
- If your tables are instead named `olist_customers_dataset`, `olist_orders_dataset`, etc., change the table names before running. Query 00 and 00B list the actual tables and columns so you can verify the mapping first.
- It is a read-only analysis script: it doesn't create or alter tables, relationships, indexes, or data.

## How to run
1. Open SQL Server Management Studio (SSMS).
2. Connect to your SQL Server instance.
3. Open `Olist_Business_Questions_SQL_Server.sql`.
4. Confirm your database is actually named `OlistDB`; if not, change the `USE` line.
5. Run Query 00 and 00B first to confirm table names/columns. If the names match, run the complete script or run one labeled question at a time.
6. Each query returns a separate result set. Review the actual results before putting numerical conclusions in the final PDF or presentation.

## Query coverage
1. Executive KPI snapshot
2. Monthly sales/order/payment trends with month-over-month growth
3. Order status distribution and cancellation share
4. Top product categories by item sales
5. Orders and unique customers by state
6. Top cities by order volume
7. Payment method contribution
8. Payment installments
9. Review score distribution
10. Review score by order status
11. Overall delivery time and on-time rate
12. Late-delivery rate by state
13. Duration of each delivery phase and date-sequence issues
14. Seller performance
15. Top products by item sales
16. Order-level reconciliation
17. Reconciliation gap summary
18. Repeat customers by lifetime item sales
19. First-observed vs repeat-customer orders over time
20. State sales ranking and cumulative share
21. Top categories within each state
22. Approval delay bands
23. Reviews for late vs on-time delivery
24. Product attribute completeness checks
25. Duplicate key checks
26. Orphan foreign-key checks
27. Timestamp completeness and chronology checks
28. Largest reconciliation discrepancies with order/customer context
29. Customers whose order count is above the average (explicit scalar subquery)

## Important calculation notes
- `item_sales` is `SUM(order_items.price)`; it excludes freight.
- `items_plus_freight` = item sales + freight.
- `payment_total` is summed from `order_payments.payment_value`.
- `Difference` = payment total − (item sales + freight). A nonzero difference is an investigation flag, not automatically profit/loss.
- `customer_unique_id` is used for distinct/repeat-customer analysis; `customer_id` links an order record to the customer table.
- Olist source column spellings such as `product_name_lenght` and `product_description_lenght` are preserved.
- Monetary measures from order items and order payments must be aggregated separately at order grain before joining, to prevent row multiplication.

## Static validation performed
- Checked the script for expected table/column references against the schema supplied in the project conversation.
- Checked that each CTE is followed by a query and that the script structure is coherent for SQL Server batches.
- This environment does not have your live `OlistDB` instance, so I could not execute the queries against the actual data. The preflight queries are included to catch schema differences before running the full analysis.
